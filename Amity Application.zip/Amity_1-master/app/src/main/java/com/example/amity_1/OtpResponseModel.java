package com.example.amity_1;

public class OtpResponseModel {
    private String success;
    private String message;

    public String getSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }
}
