package com.example.amity_1;

public class Constants {

    public static final String BASE_URL = "https://cornflowerblue-quetzal-932463.hostingersite.com/api/";
    public static final String PREFERENCE_NAME = "session";
    public static final String KEY_ISE_LOGGED_IN = "isLoggedIn";
    public static final String KEY_EMAIL = "email";
    public static final String KEY_USERNAME = "username";
}
